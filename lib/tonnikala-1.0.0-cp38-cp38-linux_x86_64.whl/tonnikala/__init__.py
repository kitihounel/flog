from .loader import FileLoader, Loader, Template

__version__ = '1.0.0'
